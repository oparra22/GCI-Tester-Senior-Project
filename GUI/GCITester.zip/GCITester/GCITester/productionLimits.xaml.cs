﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GCITester
{
    /// <summary>
    /// Interaction logic for productionLimits.xaml
    /// </summary>
    public partial class productionLimits : Window
    {
        public productionLimits()
        {
            InitializeComponent();
        }

        private void testBoardBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void partNumberBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }


        private void updownTest_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void start_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
